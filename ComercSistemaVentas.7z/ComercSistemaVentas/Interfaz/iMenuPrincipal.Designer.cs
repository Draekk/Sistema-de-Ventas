﻿namespace ComercSistemaVentas
{
    partial class iMenuPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(iMenuPrincipal));
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.btnRegistroVentas = new System.Windows.Forms.Button();
            this.btnVentas = new System.Windows.Forms.Button();
            this.btnProductos = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAperturaCaja = new System.Windows.Forms.Button();
            this.btnCierreCaja = new System.Windows.Forms.Button();
            this.pnlAbrirCaja = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCajaInicial = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGuardarCaja = new System.Windows.Forms.PictureBox();
            this.btnCloseCI = new System.Windows.Forms.PictureBox();
            this.pnlPrincipal.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlAbrirCaja.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnGuardarCaja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCloseCI)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.btnCierreCaja);
            this.pnlPrincipal.Controls.Add(this.btnAperturaCaja);
            this.pnlPrincipal.Controls.Add(this.btnRegistroVentas);
            this.pnlPrincipal.Controls.Add(this.btnVentas);
            this.pnlPrincipal.Controls.Add(this.btnProductos);
            this.pnlPrincipal.Location = new System.Drawing.Point(12, 12);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(249, 348);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // btnRegistroVentas
            // 
            this.btnRegistroVentas.BackColor = System.Drawing.Color.HotPink;
            this.btnRegistroVentas.FlatAppearance.BorderColor = System.Drawing.Color.LavenderBlush;
            this.btnRegistroVentas.FlatAppearance.BorderSize = 2;
            this.btnRegistroVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistroVentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroVentas.Location = new System.Drawing.Point(3, 142);
            this.btnRegistroVentas.Name = "btnRegistroVentas";
            this.btnRegistroVentas.Size = new System.Drawing.Size(242, 62);
            this.btnRegistroVentas.TabIndex = 2;
            this.btnRegistroVentas.Text = "REGISTRO DE VENTAS";
            this.btnRegistroVentas.UseVisualStyleBackColor = false;
            this.btnRegistroVentas.Click += new System.EventHandler(this.btnRegistroVentas_Click);
            // 
            // btnVentas
            // 
            this.btnVentas.BackColor = System.Drawing.Color.HotPink;
            this.btnVentas.FlatAppearance.BorderColor = System.Drawing.Color.LavenderBlush;
            this.btnVentas.FlatAppearance.BorderSize = 2;
            this.btnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVentas.Location = new System.Drawing.Point(3, 74);
            this.btnVentas.Name = "btnVentas";
            this.btnVentas.Size = new System.Drawing.Size(242, 62);
            this.btnVentas.TabIndex = 1;
            this.btnVentas.Text = "VENTAS";
            this.btnVentas.UseVisualStyleBackColor = false;
            this.btnVentas.Click += new System.EventHandler(this.btnVentas_Click);
            // 
            // btnProductos
            // 
            this.btnProductos.BackColor = System.Drawing.Color.HotPink;
            this.btnProductos.FlatAppearance.BorderColor = System.Drawing.Color.LavenderBlush;
            this.btnProductos.FlatAppearance.BorderSize = 2;
            this.btnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductos.Location = new System.Drawing.Point(3, 6);
            this.btnProductos.Name = "btnProductos";
            this.btnProductos.Size = new System.Drawing.Size(243, 62);
            this.btnProductos.TabIndex = 0;
            this.btnProductos.Text = "PRODUCTOS";
            this.btnProductos.UseVisualStyleBackColor = false;
            this.btnProductos.Click += new System.EventHandler(this.btnProductos_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(267, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(347, 348);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(343, 344);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnAperturaCaja
            // 
            this.btnAperturaCaja.BackColor = System.Drawing.Color.HotPink;
            this.btnAperturaCaja.FlatAppearance.BorderColor = System.Drawing.Color.LavenderBlush;
            this.btnAperturaCaja.FlatAppearance.BorderSize = 2;
            this.btnAperturaCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAperturaCaja.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAperturaCaja.Location = new System.Drawing.Point(3, 210);
            this.btnAperturaCaja.Name = "btnAperturaCaja";
            this.btnAperturaCaja.Size = new System.Drawing.Size(242, 62);
            this.btnAperturaCaja.TabIndex = 3;
            this.btnAperturaCaja.Text = "APERTURA DE CAJA";
            this.btnAperturaCaja.UseVisualStyleBackColor = false;
            this.btnAperturaCaja.Click += new System.EventHandler(this.btnAperturaCaja_Click);
            // 
            // btnCierreCaja
            // 
            this.btnCierreCaja.BackColor = System.Drawing.Color.HotPink;
            this.btnCierreCaja.FlatAppearance.BorderColor = System.Drawing.Color.LavenderBlush;
            this.btnCierreCaja.FlatAppearance.BorderSize = 2;
            this.btnCierreCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCierreCaja.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCierreCaja.Location = new System.Drawing.Point(3, 278);
            this.btnCierreCaja.Name = "btnCierreCaja";
            this.btnCierreCaja.Size = new System.Drawing.Size(242, 62);
            this.btnCierreCaja.TabIndex = 4;
            this.btnCierreCaja.Text = "CIERRE DE CAJA";
            this.btnCierreCaja.UseVisualStyleBackColor = false;
            this.btnCierreCaja.VisibleChanged += new System.EventHandler(this.btnCierreCaja_VisibleChanged);
            this.btnCierreCaja.Click += new System.EventHandler(this.btnCierreCaja_Click);
            // 
            // pnlAbrirCaja
            // 
            this.pnlAbrirCaja.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAbrirCaja.Controls.Add(this.btnCloseCI);
            this.pnlAbrirCaja.Controls.Add(this.btnGuardarCaja);
            this.pnlAbrirCaja.Controls.Add(this.label2);
            this.pnlAbrirCaja.Controls.Add(this.txtCajaInicial);
            this.pnlAbrirCaja.Controls.Add(this.label1);
            this.pnlAbrirCaja.Location = new System.Drawing.Point(180, 114);
            this.pnlAbrirCaja.Name = "pnlAbrirCaja";
            this.pnlAbrirCaja.Size = new System.Drawing.Size(246, 70);
            this.pnlAbrirCaja.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saldo actual en caja:";
            // 
            // txtCajaInicial
            // 
            this.txtCajaInicial.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCajaInicial.Location = new System.Drawing.Point(28, 28);
            this.txtCajaInicial.Name = "txtCajaInicial";
            this.txtCajaInicial.Size = new System.Drawing.Size(153, 27);
            this.txtCajaInicial.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "$";
            // 
            // btnGuardarCaja
            // 
            this.btnGuardarCaja.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardarCaja.Image")));
            this.btnGuardarCaja.Location = new System.Drawing.Point(187, 15);
            this.btnGuardarCaja.Name = "btnGuardarCaja";
            this.btnGuardarCaja.Size = new System.Drawing.Size(42, 40);
            this.btnGuardarCaja.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnGuardarCaja.TabIndex = 3;
            this.btnGuardarCaja.TabStop = false;
            this.btnGuardarCaja.Click += new System.EventHandler(this.btnGuardarCaja_Click);
            // 
            // btnCloseCI
            // 
            this.btnCloseCI.Image = ((System.Drawing.Image)(resources.GetObject("btnCloseCI.Image")));
            this.btnCloseCI.Location = new System.Drawing.Point(226, 0);
            this.btnCloseCI.Name = "btnCloseCI";
            this.btnCloseCI.Size = new System.Drawing.Size(18, 17);
            this.btnCloseCI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCloseCI.TabIndex = 4;
            this.btnCloseCI.TabStop = false;
            this.btnCloseCI.Click += new System.EventHandler(this.btnCloseCI_Click);
            // 
            // iMenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Plum;
            this.ClientSize = new System.Drawing.Size(620, 372);
            this.Controls.Add(this.pnlAbrirCaja);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlPrincipal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "iMenuPrincipal";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comerc - Menú Principal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.iMenuPrincipal_FormClosing);
            this.pnlPrincipal.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlAbrirCaja.ResumeLayout(false);
            this.pnlAbrirCaja.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnGuardarCaja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCloseCI)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Button btnProductos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnVentas;
        private System.Windows.Forms.Button btnRegistroVentas;
        private System.Windows.Forms.Button btnCierreCaja;
        private System.Windows.Forms.Button btnAperturaCaja;
        private System.Windows.Forms.Panel pnlAbrirCaja;
        private System.Windows.Forms.PictureBox btnCloseCI;
        private System.Windows.Forms.PictureBox btnGuardarCaja;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCajaInicial;
        private System.Windows.Forms.Label label1;
    }
}

