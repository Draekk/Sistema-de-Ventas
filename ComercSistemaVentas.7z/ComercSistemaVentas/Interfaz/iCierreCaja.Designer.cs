﻿namespace ComercSistemaVentas.Interfaz
{
    partial class iCierreCaja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCajaFinal = new System.Windows.Forms.Label();
            this.lblTotalEgresos = new System.Windows.Forms.Label();
            this.lblVentaTotal = new System.Windows.Forms.Label();
            this.lblVentasOtros = new System.Windows.Forms.Label();
            this.lblVentasTarjeta = new System.Windows.Forms.Label();
            this.lblVentasEfectivo = new System.Windows.Forms.Label();
            this.lblCajaInicial = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.btnCerrarCaja = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblCajaFinal);
            this.panel1.Controls.Add(this.lblTotalEgresos);
            this.panel1.Controls.Add(this.lblVentaTotal);
            this.panel1.Controls.Add(this.lblVentasOtros);
            this.panel1.Controls.Add(this.lblVentasTarjeta);
            this.panel1.Controls.Add(this.lblVentasEfectivo);
            this.panel1.Controls.Add(this.lblCajaInicial);
            this.panel1.Location = new System.Drawing.Point(218, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(156, 278);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(12, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 278);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "CAJA INICIAL:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "VENTAS EFECTIVO:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(197, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "VENTAS OTROS:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(197, 23);
            this.label4.TabIndex = 4;
            this.label4.Text = "VENTAS TARJETA:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(3, 244);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(197, 23);
            this.label6.TabIndex = 8;
            this.label6.Text = "CAJA FINAL:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(3, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 23);
            this.label7.TabIndex = 7;
            this.label7.Text = "TOTAL EGRESOS:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(3, 168);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(197, 23);
            this.label8.TabIndex = 6;
            this.label8.Text = "VENTA TOTAL:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCajaFinal
            // 
            this.lblCajaFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCajaFinal.ForeColor = System.Drawing.Color.White;
            this.lblCajaFinal.Location = new System.Drawing.Point(-2, 242);
            this.lblCajaFinal.Name = "lblCajaFinal";
            this.lblCajaFinal.Size = new System.Drawing.Size(151, 23);
            this.lblCajaFinal.TabIndex = 15;
            this.lblCajaFinal.Text = "$12.345.678";
            this.lblCajaFinal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotalEgresos
            // 
            this.lblTotalEgresos.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalEgresos.ForeColor = System.Drawing.Color.Red;
            this.lblTotalEgresos.Location = new System.Drawing.Point(-2, 204);
            this.lblTotalEgresos.Name = "lblTotalEgresos";
            this.lblTotalEgresos.Size = new System.Drawing.Size(151, 23);
            this.lblTotalEgresos.TabIndex = 14;
            this.lblTotalEgresos.Text = "$12.345.678";
            this.lblTotalEgresos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVentaTotal
            // 
            this.lblVentaTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentaTotal.ForeColor = System.Drawing.Color.Lime;
            this.lblVentaTotal.Location = new System.Drawing.Point(-2, 166);
            this.lblVentaTotal.Name = "lblVentaTotal";
            this.lblVentaTotal.Size = new System.Drawing.Size(151, 23);
            this.lblVentaTotal.TabIndex = 13;
            this.lblVentaTotal.Text = "$12.345.678";
            this.lblVentaTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVentasOtros
            // 
            this.lblVentasOtros.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentasOtros.ForeColor = System.Drawing.Color.White;
            this.lblVentasOtros.Location = new System.Drawing.Point(-2, 128);
            this.lblVentasOtros.Name = "lblVentasOtros";
            this.lblVentasOtros.Size = new System.Drawing.Size(151, 23);
            this.lblVentasOtros.TabIndex = 12;
            this.lblVentasOtros.Text = "$12.345.678";
            this.lblVentasOtros.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVentasTarjeta
            // 
            this.lblVentasTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentasTarjeta.ForeColor = System.Drawing.Color.White;
            this.lblVentasTarjeta.Location = new System.Drawing.Point(-2, 90);
            this.lblVentasTarjeta.Name = "lblVentasTarjeta";
            this.lblVentasTarjeta.Size = new System.Drawing.Size(151, 23);
            this.lblVentasTarjeta.TabIndex = 11;
            this.lblVentasTarjeta.Text = "$12.345.678";
            this.lblVentasTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVentasEfectivo
            // 
            this.lblVentasEfectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentasEfectivo.ForeColor = System.Drawing.Color.White;
            this.lblVentasEfectivo.Location = new System.Drawing.Point(-2, 52);
            this.lblVentasEfectivo.Name = "lblVentasEfectivo";
            this.lblVentasEfectivo.Size = new System.Drawing.Size(151, 23);
            this.lblVentasEfectivo.TabIndex = 10;
            this.lblVentasEfectivo.Text = "$12.345.678";
            this.lblVentasEfectivo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCajaInicial
            // 
            this.lblCajaInicial.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCajaInicial.ForeColor = System.Drawing.Color.White;
            this.lblCajaInicial.Location = new System.Drawing.Point(-2, 14);
            this.lblCajaInicial.Name = "lblCajaInicial";
            this.lblCajaInicial.Size = new System.Drawing.Size(151, 23);
            this.lblCajaInicial.TabIndex = 9;
            this.lblCajaInicial.Text = "$12.345.678";
            this.lblCajaInicial.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(128, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 23);
            this.label15.TabIndex = 3;
            this.label15.Text = "FECHA:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFecha
            // 
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.ForeColor = System.Drawing.Color.White;
            this.lblFecha.Location = new System.Drawing.Point(214, 9);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(156, 23);
            this.lblFecha.TabIndex = 10;
            this.lblFecha.Text = "DD-MM-YYYY";
            this.lblFecha.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCerrarCaja
            // 
            this.btnCerrarCaja.BackColor = System.Drawing.Color.Red;
            this.btnCerrarCaja.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.btnCerrarCaja.FlatAppearance.BorderSize = 2;
            this.btnCerrarCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarCaja.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarCaja.ForeColor = System.Drawing.Color.White;
            this.btnCerrarCaja.Location = new System.Drawing.Point(106, 330);
            this.btnCerrarCaja.Name = "btnCerrarCaja";
            this.btnCerrarCaja.Size = new System.Drawing.Size(175, 70);
            this.btnCerrarCaja.TabIndex = 11;
            this.btnCerrarCaja.Text = "CERRAR CAJA";
            this.btnCerrarCaja.UseVisualStyleBackColor = false;
            this.btnCerrarCaja.Click += new System.EventHandler(this.btnCerrarCaja_Click);
            // 
            // iCierreCaja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(385, 450);
            this.Controls.Add(this.btnCerrarCaja);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "iCierreCaja";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comerc - Cierre de Caja";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.iCierreCaja_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCajaFinal;
        private System.Windows.Forms.Label lblTotalEgresos;
        private System.Windows.Forms.Label lblVentaTotal;
        private System.Windows.Forms.Label lblVentasOtros;
        private System.Windows.Forms.Label lblVentasTarjeta;
        private System.Windows.Forms.Label lblVentasEfectivo;
        private System.Windows.Forms.Label lblCajaInicial;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Button btnCerrarCaja;
    }
}