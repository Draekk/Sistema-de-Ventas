﻿using ComercSistemaVentas.Conexion;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace ComercSistemaVentas.Operadores
{
    internal class Egresos_O
    {
        public bool InsertarEgreso(int monto, string motivo)
        {
			try
			{
                ConexionDB con = new ConexionDB();
                string sql = $"insert into DiarioEgresos values({monto}, '{motivo}', getdate())";
                SqlCommand comando = new SqlCommand(sql, con.Conectar());
                int filas = comando.ExecuteNonQuery();

                if (filas == 1)
                {
                    con.Desconectar();
                    return true;
                }
                return false;
            }
			catch (Exception)
			{
                return false;
			}
        }
    }
}
